package com.backend.busmap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BusmapApplicationTests {

	@Test
	void contextLoads() {
	}

}
