package com.backend.busmap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BusmapApplication {

	public static void main(String[] args) {
		SpringApplication.run(BusmapApplication.class, args);
	}

}
